package com.capgemini.onlinetest.main;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

import java.util.List;
import java.util.Map;
import java.io.IOException;
import java.util.ArrayList;

import com.capgemini.onlinetest.dto.*;
import com.capgemini.onlinetest.services.*;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException, IOException  
	{
		Scanner sc=new Scanner(System.in);
		
		//ADD USERS
		//UserServices.addUsers(sc);	
		
		
		System.out.println("Login : ");
		System.out.println("For Admin(Press 1) For User(Press 2)");	
		int admin_or_user = sc.nextInt();
		
		if(admin_or_user == 1)
		{
			if(AdminServices.login())
			{
				
				
			}else {
				System.out.println("Your program ends here.");
			}

		}else if(admin_or_user == 2){
			if(UserServices.login(sc))
			{
				System.out.println("Lets begin the program");
				
			}else {
				System.out.println("Your program ends here.");
			}
		}
		
	}
}