package com.capgemini.onlinetest.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlinetest.dto.Questions;
import com.capgemini.onlinetest.dto.Test;
import com.capgemini.onlinetest.dto.User;

public class UserServices {
	
	public static void giveTest(Scanner sc)
	{
		System.out.println("Enter the test id which you want to give test : ");
		int testid = sc.nextInt();
		int totalmarks = 0;
		
		Test obj = AllTests.alltests.get(testid);
		List<Questions> ques = obj.getTestQuestions();
		int totalquestions = ques.size();
		
		for(int i=0; i<totalquestions; i++)
		{
			Questions q = ques.get(i);
			System.out.println(q.getQuestionTitle());
			System.out.println(q.getQuestionOptions());
			int ans = sc.nextInt();
			q.setChosenAnswer(ans);
			
			if(q.getQuestionAnswer() == q.getChosenAnswer())
			{
				totalmarks++;
			}
			
		}
		
		System.out.println(" Marks obtained : "+totalmarks+"out of "+totalquestions);
		
		System.out.println();
			
	}
	
	static List<User> all_users = new ArrayList<User>();
	
	public static void addUsers(Scanner sc)
	{
		
		//Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter number of users : ");
		int n_users = sc.nextInt();
		sc.nextLine();
		
		for(int i=0; i<n_users; i++) 
		{
			
			System.out.println("Enter userid : ");
			int userid = sc.nextInt();
			sc.nextLine();
			
			System.out.println("Enter password : ");
			String password = sc.nextLine();
			
			all_users.add(new User(userid, password));
			
		}
		
		 String filename = "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\allusersEntry.txt";
		 
		 try
	        {    
	            //Saving of object in a file 
	            FileOutputStream file = new FileOutputStream(filename); 
	            ObjectOutputStream out = new ObjectOutputStream(file); 
	              
	            // Method for serialization of object 
	            	out.writeObject(all_users);
	              
	            out.close(); 
	            file.close(); 
	              
	            System.out.println("Users have been entered. "); 
	  
	        }
	        catch(IOException ex) 
	        { 
	            System.out.println("Error occured. Users can't be entered."); 
	        } 
	}
	
	
	//DeSerialization
	public static boolean login(Scanner sc)
	{
		//Scanner sc = new Scanner(System.in);
		
		boolean b = false;
		
		 String filename = "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\allusersEntry.txt";

		 List<User> user2 = new ArrayList<User>();
		 
		 FileInputStream f;
		 try {
			f = new FileInputStream(filename);
			 ObjectInputStream s;
			try
			{
				s = new ObjectInputStream(f);
				
				try {
					//
					User u = (User) s.readObject();

					System.out.println(u);
				}
				catch (ClassNotFoundException e) {
				
					e.printStackTrace();
				}
			
			} catch (IOException e)
			{
				e.printStackTrace();
			}
		}catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		 
		 
		 System.out.println("Enter your user id : ");
		 int userid =sc.nextInt();
		 sc.nextLine();
		
		for(User user: user2)
		{
			if(user.getUserid() == userid )
			{	System.out.println("Enter your password");
				String password=sc.nextLine();
				
				if(user.getUserPassword().equals(password))
				{
					b = true;
					System.out.println("Login Successfull.");
				}
				else
				{
					System.out.println("Errr...!! Wrong PASSWORD !!");
				}
			}
			else
			{
				System.out.println("Username does not exist.");
			}
		}		
		return b;
	}	
	
	
}