package com.capgemini.onlinetest.services;

import com.capgemini.onlinetest.services.AllTests;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;

import com.capgemini.onlinetest.dto.Questions;
import com.capgemini.onlinetest.dto.Test;

public class AdminServices {
	
	static Scanner sc = new Scanner(System.in);
	
	public static void addTest() 
	{
		System.out.println("Enter test id : ");
		int test_id = sc.nextInt();
		Test obj = new Test(test_id);
		
		String filename = "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\allTests.txt";
		
		LinkedHashMap<Integer, Test> alltests = new LinkedHashMap<Integer, Test>();
		
		 try
	        {    
	            //Saving of object in a file 
	            FileInputStream file = new FileInputStream(filename); 
	            ObjectInputStream out = new ObjectInputStream(file); 
	              
	            // Method for serialization of object 
	            
	            alltests = (LinkedHashMap<Integer, Test>) out.readObject();
	            alltests.put(test_id, obj);
	            out.close(); 
	            file.close(); 
	            
	            System.out.println("ALLTESTS have been DeSerialized");    
	            
	        }catch(IOException ex) 
	        { 
	            System.out.println("ALLTESTS cant be SERIALIZED"); 
	        } catch (ClassNotFoundException e) {
				e.printStackTrace();
			} 
		 
		 try
	        {    
	            //Saving of object in a file 
	            FileOutputStream files = new FileOutputStream(filename); 
	            ObjectOutputStream outs = new ObjectOutputStream(files); 
	              
	            // Method for serialization of object  
	            outs.writeObject(alltests);
	            
	            outs.close(); 
	            files.close(); 
	              
	            System.out.println("ALLTESTS have been Serialized"); 
	  
	        }
	        catch(IOException ex) 
	        { 
	            System.out.println("ALLTESTS cant be SERIALIZED."); 
	        } 
		System.out.println("Test "+test_id+" added successfully");
	}
	
	public static void deleteTest(int testid)
	{
		String filename = "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\allTests.txt";
		
		LinkedHashMap<Integer, Test> alltests = new LinkedHashMap<Integer, Test>();
		
		try
        {    
            //Saving of object in a file 
            FileInputStream file = new FileInputStream(filename); 
            ObjectInputStream out = new ObjectInputStream(file); 
              
            // Method for serialization of object 
            
            alltests = (LinkedHashMap<Integer, Test>) out.readObject();
            out.close(); 
            file.close();             
        }catch(IOException ex) 
        { 
        	ex.printStackTrace();
        } catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		
		if(alltests.containsKey(testid))
		{
			alltests.remove(testid);
			 try
		        {    
		            //Saving of object in a file 
		            FileOutputStream files = new FileOutputStream(filename); 
		            ObjectOutputStream outs = new ObjectOutputStream(files); 
		              
		            // Method for serialization of object  
		            outs.writeObject(alltests);
		            
		            outs.close(); 
		            files.close(); 
		            System.out.println("Test "+testid+" removed successfully");
		            System.out.println("ALLTESTS have been Serialized"); 
		        }
		        catch(IOException ex) 
		        { 
		            System.out.println("Test not deleted. ALLTESTS cant be SERIALIZED. "); 
		        } 
		}else {
			System.out.println("Test not found ");
		}
	}
	
	public static void addQuestion()
	{
		System.out.println("Enter testid where you want to add this question : ");
		int testid = sc.nextInt();
		
		System.out.println("Enter question id : ");
		int quesid = sc.nextInt();
		sc.nextLine();
		
		System.out.println("Enter question : ");
		String ques = sc.nextLine();
		
		List<String> qOptions = new ArrayList<String>();
		System.out.println("Enter options : ");
		for(int i=0; i<4; i++)
		{
			qOptions.add(sc.nextLine());
		}
		
		System.out.println("Enter its answer : ");
		int ans = sc.nextInt();
		
		Questions q = new Questions(quesid, ques, qOptions, ans);		
		
		String filename = "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\allTests.txt";
		
		LinkedHashMap<Integer, Test> alltests = new LinkedHashMap<Integer, Test>();
		
		try
	    {    
	            //Saving of object in a file 
	            FileInputStream file = new FileInputStream(filename); 
	            ObjectInputStream out = new ObjectInputStream(file); 
	              
	            // Method for serialization of object 
	            
	            alltests = (LinkedHashMap<Integer, Test>) out.readObject();
	            
	            Test obj = alltests.get(testid);
	    		List<Questions> objj = obj.getTestQuestions();
	    		objj.add(q);
	            
	    		out.close(); 
	            file.close(); 
	            
	            System.out.println(" ALLTESTS have been DeSerialized.");    
	            
	        }catch(IOException ex) 
	        { 
	            System.out.println("ALLTESTS cant be SERIALIZED"); 
	        } catch (ClassNotFoundException e) {
				e.printStackTrace();
			} 
		 
		 try
	        {    
	            //Saving of object in a file 
	            FileOutputStream files = new FileOutputStream(filename); 
	            ObjectOutputStream outs = new ObjectOutputStream(files); 
	              
	            // Method for serialization of object  
	            outs.writeObject(alltests);
	            
	            outs.close(); 
	            files.close(); 
	              
	            System.out.println("Question has been added and ALLTESTS have been Serialized"); 
	  
	        }
	        catch(IOException ex) 
	        { 
	            System.out.println("ALLTESTS cant be SERIALIZED."); 
	        } 
		
	}
	
	public static void deleteQuestion()
	{
		
		LinkedHashMap<Integer, Test> alltests = new LinkedHashMap<Integer, Test>();

		System.out.println("Enter question id you want to delete : ");
		int quesid = sc.nextInt();
		int flag = 0;
		for(int i=0; i<AllTests.alltests.size(); i++)
		{
			Test obj = AllTests.alltests.get(i);
			List<Questions> objj = obj.getTestQuestions();
			for(int j=0; j<objj.size(); j++)
			{
				Questions q = objj.get(j);
				if(q.getQuestionid() == quesid)
				{
					objj.remove(j);
					flag = 1;
					System.out.println("Question removed successfully");
					break;
				}
			}		
			if(flag == 1)
				break;
		}
		if(flag == 0)
		{
			System.out.println("Question not found");
		}
	}
	
	public static boolean login()
	{
		boolean b= false;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter admin id");
		String admin=sc.nextLine();
		
		System.out.println("Enter password");
		String pass=sc.nextLine();
	
		if(admin.equalsIgnoreCase("admin") && pass.equalsIgnoreCase("admin"))
		{
			b = true;
			System.out.println("ADMIN LOGIN SUCCESSFULL !");
			System.out.println("Select the task you want to do -:");
			System.out.println("Press 1 - ADD TEST");
			System.out.println("Press 2 - DELETE TEST");
			System.out.println("Press 3 - ADD QUESTION");
			System.out.println("Press 4 - DELETE QUESTION");
			int x=sc.nextInt();
			
			switch(x)
			{
				case 1:AdminServices.addTest();
						break;
				case 2:
					System.out.println("Enter test id of test you want to delete : ");
					int testid = sc.nextInt();
					AdminServices.deleteTest(testid);
						break;
				case 3:AdminServices.addQuestion();
						break;
				case 4:AdminServices.deleteQuestion();
						break;
			}
		}else
		{
			System.out.println("Wrong Credentials , Try Again..");
		}
		return b;
	}
}
