package com.capgemini.onlinetest.services;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.LinkedHashMap;

import com.capgemini.onlinetest.dto.*;

public class AllTests {
	
	static LinkedHashMap<Integer, Test> alltests = new LinkedHashMap<Integer, Test>();

	
	public static void main(String[] args) {
		
		System.out.println(alltests.keySet());
		
		
		
	}
	/*
	 * public static void alltests() {
	 * 
	 * String filename =
	 * "C:\\Users\\akash\\Desktop\\Project\\OnlineTest\\alltests.txt";
	 * 
	 * try { FileOutputStream file = new FileOutputStream(filename);
	 * ObjectOutputStream out = new ObjectOutputStream(file);
	 * 
	 * out.writeObject(alltests);
	 * 
	 * } catch(IOException e) { System.out.println(""); } }
	 */
}
